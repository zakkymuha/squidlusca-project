#ifndef	__LIBMIME_MIMEHDRS_H__
#define	__LIBMIME_MIMEHDRS_H__

extern size_t headersEnd(const char *mime, size_t l);

#endif
