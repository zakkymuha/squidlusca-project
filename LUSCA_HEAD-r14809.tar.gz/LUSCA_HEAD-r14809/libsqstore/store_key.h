#ifndef	__LIBSQSTORE_STORE_H__
#define	__LIBSQSTORE_STORE_H__

/* the SQUID_MD5_DIGEST_LENGTH is defined in include/squid_md5.h .. */


#endif
