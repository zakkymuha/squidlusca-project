#ifndef	__LUSCA_LIBSQURL_DOMAIN_H__
#define	__LUSCA_LIBSQURL_DOMAIN_H__

extern int matchDomainName(const char *h, const char *d);

#endif
