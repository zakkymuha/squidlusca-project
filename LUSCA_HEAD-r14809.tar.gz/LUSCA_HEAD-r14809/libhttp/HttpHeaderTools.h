#ifndef	LIBHTTP_HTTPHEADERTOOLS_H__
#define	LIBHTTP_HTTPHEADERTOOLS_H__

extern int httpHeaderHasConnDir(const HttpHeader * hdr, const char *directive);

#endif
