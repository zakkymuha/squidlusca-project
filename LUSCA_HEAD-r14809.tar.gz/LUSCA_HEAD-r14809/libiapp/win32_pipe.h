#ifndef	__WIN32_PIPE_H__
#define	__WIN32_PIPE_H__

extern int WIN32_pipe(int handles[2]);

#endif
