#ifndef	__LIBIAPP_MAINLOOP_H__
#define	__LIBIAPP_MAINLOOP_H__

extern void iapp_init(void);
extern int iapp_runonce(int msec);

#endif
