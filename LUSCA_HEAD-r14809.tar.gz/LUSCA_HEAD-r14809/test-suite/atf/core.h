#ifndef	__TEST_CORE_H__
#define	__TEST_CORE_H__

extern void test_core_init(void);

#endif
