#include "../include/config.h"

#include "win32_version.h"

unsigned int WIN32_OS_version = 0;
char *WIN32_OS_string = NULL;

