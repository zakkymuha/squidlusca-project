#ifndef	__INCLUDE_HEX_H__
#define	__INCLUDE_HEX_H__

extern void hex_from_byte_array(char *dst, const char *src, int srclen);

#endif
