#ifndef	__LUSCA_WIN32_VERSION_H__
#define	__LUSCA_WIN32_VERSION_H__

extern unsigned int WIN32_OS_version;   /* 0 */
extern char *WIN32_OS_string;   /* NULL */

#endif
