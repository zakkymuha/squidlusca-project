#ifndef	__INCLUDE_DRAND48_H__
#define	__INCLUDE_DRAND48_H__

#if !HAVE_DRAND48
double drand48(void);
#endif

#endif
