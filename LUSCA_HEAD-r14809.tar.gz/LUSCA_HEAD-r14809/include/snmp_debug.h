/*
 * $Id: snmp_debug.h 10514 2005-05-17 16:56:44Z hno $
 */

#ifndef SQUID_SNMP_DEBUG_H
#define SQUID_SNMP_DEBUG_H

extern void 
snmplib_debug(int, const char *,...) PRINTF_FORMAT_ARG2;

#endif /* SQUID_SNMP_DEBUG_H */
