#ifndef	__LIBCORE_STRUTIL_H__
#define	__LIBCORE_STRUTIL_H__

extern int strmatchbeg(const char *search, const char *match, int maxlen);
extern int strmatch(const char *search, const char *match, int maxlen);

#endif
