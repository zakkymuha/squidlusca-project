#ifndef	__LIBCORE_DEBUG_H__
#define __LIBCORE_DEBUG_H__

#include "../libsqdebug/debug.h"

#endif
